package fi.tuni.lazymanatees.blog;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import java.util.List;

@RestController
public class BlogController {

    @Autowired
    DatabaseHandler blogdatabase;

    @PostConstruct
    public void init() {
        blogdatabase.save(new BlogObject("Tester 1", "Random shit"));
        blogdatabase.save(new BlogObject("Tester 2", "More random shit"));
        blogdatabase.save(new BlogObject("Tester 3", "Even more random shit"));
    }

    @RequestMapping(value = "/blogposts", method = RequestMethod.GET)
    public Iterable<BlogObject> fetch() {
        return blogdatabase.findAll();
    }

    /**
    @PostMapping("/save/{uName}{blogpost}")
    private void saveBlogObject(@RequestBody BlogObject o) {
        o.saveBlogObject("uname");
    }
    */
}
